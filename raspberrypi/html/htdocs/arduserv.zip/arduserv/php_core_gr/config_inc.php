<?php
	session_start();
	
	$mysql_addr="localhost";
	$mysql_db="nmea_db_gr";

	$mysql_login="root";
	$mysql_password="mysqlpasswd";

	$mysql_db_connect = mysqli_connect($mysql_addr, $mysql_login, $mysql_password, $mysql_db);//$mysql_addr, $mysql_login, $mysql_password


?>